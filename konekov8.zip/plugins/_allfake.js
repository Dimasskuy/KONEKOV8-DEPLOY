import fs from 'fs'
import fetch from 'node-fetch'
import moment from 'moment-timezone'
import { promises, readFileSync } from 'fs'
let handler = m => m
handler.all = async function (m) {
let pp
try {
pp = AraChu2.getRandom()
} catch (e) {
pp = await this.profilePictureUrl(m.sender, 'image')
} finally {
global.ephemeral = "86400"
global.kontak2 = [
[owner[0], await conn.getName(owner[0] + '6283181666350@s.whatsapp.net'), 'ᴅᴇᴠᴇʟᴏᴩᴇʀ ʙᴏᴛ', 'f999@gmail.com', true],
[owner[1], await conn.getName(owner[1] + '@s.whatsapp.net'), 'ᴅᴇᴠᴇʟᴏᴩᴇʀ ʙᴏᴛ', 'f1000@gmail.com', true],
]
global.pppkecil = AraChu2.getRandom()
global.ucapan = ucapan()
global.ppkecil = {
            contextInfo: {
            externalAdReply: {
                showAdAttribution: true,
                title: `ᴋᴏɴᴇᴋᴏ ᴄʏᴢ`,
                body: global.author,
                thumbnail: await fs.readFileSync("./thumbnail.jpg"),
                thumbnailUrl: pppkecil,
                sourceUrl: `https://s.id/ReyzShop`,
                mediaType: 1,
                renderLargerThumbnail: false
            }
        }
    }
    
    /* Fake adReplyS*/
global.adReplyS = {
    fileLength: 999,
    seconds: 999,
    contextInfo: {
        forwardingScore: 2023,
        externalAdReply: {
            containsAutoReply: true,
            showAdAttribution: true,
            title: "👋 " + Sapa() + Pagi(),
            body: author,
            mediaUrl: sgc,
            description: "𝑾𝒖𝒅𝒚𝒔𝒐𝒇𝒕",
            previewType: "PHOTO",
            thumbnail: await fs.readFileSync("./55111188_p0.jpg"),
            sourceUrl:  "https://リコリス・リコイル",
        }
    }
}
/* Fake adReply */
global.adReply = {
    fileLength: 999,
    seconds: 999,
    contextInfo: {
        forwardingScore: 2023,
        externalAdReply: {
            body: author,
            containsAutoReply: true,
            mediaType: 1,
            mediaUrl:  sgc,
            renderLargerThumbnail: true,
            showAdAttribution: true,
            sourceId: "𝑾𝒖𝒅𝒚𝒔𝒐𝒇𝒕",
            sourceType: "PDF",
            previewType: "PDF",
            sourceUrl:  sgc,
           thumbnail: await fs.readFileSync("./55111188_p0.jpg"),
            thumbnailUrl: global.logo,
            title: "👋 " + Sapa() + Pagi()
        }
    }
}
/* Fake IG */
global.fakeig = {
    contextInfo: {
        externalAdReply: {
            showAdAttribution: true,
            mediaUrl: sig,
            mediaType: "VIDEO",
            description: "Follow: " + sig,
            title: "👋 " + Sapa() + Pagi(),
            body: author,
            thumbnailUrl: global.logo,
            sourceUrl: sgc
        }
    }
}
/* Fake FB */
global.fakefb = {
    contextInfo: {
        externalAdReply: {
            showAdAttribution: true,
            mediaUrl: sfb,
            mediaType: "VIDEO",
            description: "Follow: " + sig,
            title: "👋 " + Sapa() + Pagi(),
            body: author,
            thumbnailUrl: global.logo,
            sourceUrl: sgc
        }
    }
}
/* Fake TT */
global.faketik = {
    contextInfo: {
        externalAdReply: {
            showAdAttribution: true,
            mediaUrl: snh,
            mediaType: "VIDEO",
            description: "Follow: " + sig,
            title: "👋 " + Sapa() + Pagi(),
            body: author,
            thumbnailUrl: global.logo,
            sourceUrl: snh
        }
    }
}
/* Fake YT */
global.fakeyt = {
    contextInfo: {
        externalAdReply: {
            showAdAttribution: true,
            mediaUrl: syt,
            mediaType: "VIDEO",
            description: "Follow: " + sig,
            title: "👋 " + Sapa() + Pagi(),
            body: author,
            thumbnailUrl: global.logo,
            sourceUrl: syt
        }
    }
}
global.fakes = Fakes()
/*=========== TYPE DOCUMENT ===========*/
global.dpptx = 'application/vnd.openxmlformats-officedocument.presentationml.presentation'
global.ddocx = 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
global.dxlsx = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
global.dpdf = 'application/pdf'
global.drtf = 'text/rtf'
global.djson = 'application/json'
global.thumbdoc = 'https://telegra.ph/file/6e45318d7c76f57e4a8bd.jpg'
global.doc = pickRandom(["application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel", "application/msword", "application/pdf", "text/rtf"])
global.thumbnailUrl2 = [
'https://telegra.ph/file/db75462f860ed003d0170.jpg',
'https://telegra.ph/file/eab0a392d4a9150d773ec.jpg',
'https://telegra.ph/file/a42fa519ac38adde33dcf.jpg',
'https://telegra.ph/file/c843d378e9b9bfc4dd902.jpg',
'https://telegra.ph/file/6bbc82078f1a324addc01.jpg',
'https://telegra.ph/file/ab6f519983c755f61cd60.jpg'
]
global.cecan = [
        "https://i.pinimg.com/736x/30/93/0b/30930baa10607143bec6356a76280a8a.jpg",
        "https://i.pinimg.com/736x/90/da/29/90da2901c59ef7aaf7c3c8cee0503f64.jpg",
        "https://i.pinimg.com/736x/93/fd/86/93fd86c7c86c13c7b9703f3e30a11e4d.jpg",
        "https://i.pinimg.com/736x/78/70/27/7870273cd16ed5476217df2b22286f83.jpg",
        "https://i.pinimg.com/736x/78/52/90/785290609e82657a0959217c759c3d43.jpg",
        "https://i.pinimg.com/736x/e8/b4/f5/e8b4f5dc252ec6b3ecb55662d4403bdf.jpg",
        "https://i.pinimg.com/736x/62/da/23/62da234d941080696428e6d4deec6d73.jpg",
        "https://i.pinimg.com/736x/7e/84/2c/7e842c728cc55cbb141dfa392f95763d.jpg",
        "https://i.pinimg.com/736x/b8/de/15/b8de15522d308399d176cdbf912d87c4.jpg",
        "https://i.pinimg.com/736x/e7/c5/bd/e7c5bd8a58aed3268582dfb90140111f.jpg",
        "https://i.pinimg.com/736x/3f/15/a6/3f15a6145a63e34825ca6a2947931ff7.jpg",
        "https://i.pinimg.com/736x/df/0a/43/df0a43fc8530562d16dc8e4840d3f714.jpg",
        "https://i.pinimg.com/736x/fc/3f/e1/fc3fe174368601df6e3160d9c027a718.jpg",
        "https://i.pinimg.com/736x/8c/f9/50/8cf950b340fde28de243d89b92f84b90.jpg",
        "https://i.pinimg.com/736x/21/99/d1/2199d11e7408948e24cfd792c60caa9b.jpg",
        "https://i.pinimg.com/736x/08/11/e2/0811e2fb69d43ed0dd831a9ef8d424ff.jpg",
        "https://i.pinimg.com/736x/fb/89/8a/fb898adcd3090d2e852af1b2a5a9544d.jpg",
        "https://i.pinimg.com/736x/db/0d/a5/db0da5d5fb6b44d7ceed7f874d85f59b.jpg",
        "https://i.pinimg.com/736x/f8/97/ad/f897ade4cfef5f85b88cbf8697d0417e.jpg",
        "https://i.pinimg.com/736x/98/6f/3b/986f3b75982ffd22a3af088b701ccb13.jpg",
        "https://i.pinimg.com/736x/c1/bd/47/c1bd4702bd709e7b3307d22c297a4754.jpg",
        "https://i.pinimg.com/736x/20/de/73/20de731550f239270016de3603d8b788.jpg",
        "https://i.pinimg.com/736x/42/62/55/4262552672c5c1f2bd375ad2ab403042.jpg",
        "https://i.pinimg.com/736x/18/44/a6/1844a6800c6f63af674521bf9886216c--ulzzang-korea-korean-ulzzang.jpg",
        "https://i.pinimg.com/736x/71/f9/1a/71f91a6e056d47e03171d0f1f594edd1.jpg",
        "https://i.pinimg.com/736x/bc/87/4e/bc874e3a7672d1b4bf2b1cadcbaefc70.jpg",
        "https://i.pinimg.com/736x/c1/0d/dc/c10ddc95d187b46557c7149ef2f0ddfa.jpg",
        "https://i.pinimg.com/736x/9b/92/fa/9b92faced78923340dfcce5c513e3b28.jpg",
        "https://i.pinimg.com/736x/47/00/8a/47008ae35b3c4d0ceaf6f3e2e4f33c69.jpg",
        "https://i.pinimg.com/736x/0d/bc/18/0dbc18f2edf2b70ccce348b1082c98f7.jpg",
        "https://i.pinimg.com/736x/82/5d/8d/825d8d57f8c273f4b3fe3cdd6345b6d5.jpg",
        "https://i.pinimg.com/736x/88/24/74/8824740a20f7dc839b7ed4454b4847c3.jpg",
        "https://i.pinimg.com/736x/d7/60/a2/d760a2aa6c8306ed1652233d566f2d4d.jpg",
        "https://i.pinimg.com/736x/02/5d/7b/025d7b46ede75db2c4367c686133f41e.jpg",
        "https://i.pinimg.com/736x/14/5b/d8/145bd8692c7a96de5882044a0307eae0.jpg",
        "https://i.pinimg.com/736x/c0/1a/f5/c01af5fcf445b684c9cf3fb9ed122c75.jpg",
        "https://i.pinimg.com/736x/d6/f2/dd/d6f2ddaf9b678cbb57e44ac31c347400.jpg",
        "https://i.pinimg.com/736x/cc/ef/96/ccef9671e362deb57e1d60c66ee5aed9.jpg",
        "https://i.pinimg.com/736x/f0/ce/67/f0ce677882212c64ef2e2a1e62e0ba9b.jpg",
        "https://i.pinimg.com/736x/5f/02/82/5f0282313a7370c9afc902c74b3a46d3.jpg",
        "https://i.pinimg.com/736x/6c/5e/c3/6c5ec3f0a3eaa9622705d579a2866b26.jpg",
        "https://i.pinimg.com/736x/aa/11/84/aa1184073f64ff15c5e42d02d4b10d4d.jpg",
        "https://i.pinimg.com/736x/9c/15/d7/9c15d7e9e8119f45f65b85a7bb4245d9.jpg",
        "https://i.pinimg.com/736x/83/a5/27/83a52761898778a84bb2339c8b8a802b.jpg",
        "https://i.pinimg.com/736x/2e/c3/da/2ec3da82547e02434efb0bbc26fe39c2.jpg",
        "https://i.pinimg.com/736x/06/1d/9e/061d9e540761238f4465fec66cc1da2e.jpg",
        "https://i.pinimg.com/736x/a7/d9/1d/a7d91dae6c7ead221f269c8a9a6a35f5.jpg",
        "https://i.pinimg.com/736x/5c/72/eb/5c72ebf949634726fe26151263542ea3.jpg",
        "https://i.pinimg.com/736x/db/66/cb/db66cb7b23d581d860276e762855d53b.jpg",
        "https://i.pinimg.com/736x/2e/02/a9/2e02a92e9aeb6c52797d97de16883366.jpg",
        "https://i.pinimg.com/736x/2c/06/33/2c06332146f33e4717d47cbac54f2cb1.jpg",
        "https://i.pinimg.com/736x/7c/42/88/7c428863a7bef67f2e13db0a2d2e9e36.jpg",
        "https://i.pinimg.com/736x/da/4f/d0/da4fd04c5302d2d0594bda3c71d3af80.jpg",
        "https://i.pinimg.com/736x/26/1b/30/261b30ce67142f2fb201e0236b071180.jpg",
        "https://i.pinimg.com/736x/8e/e8/28/8ee8282f7b1e2382994cf616d3459880.jpg",
        "https://i.pinimg.com/736x/3e/24/b1/3e24b1cbcfe14e754063d280d8c177a9.jpg",
        "https://i.pinimg.com/736x/03/c9/87/03c98776cc866ab7d19578fd324ca68e.jpg",
        "https://i.pinimg.com/736x/c3/05/b3/c305b30c774abd00e4a201d4a5757ad6.jpg",
        "https://i.pinimg.com/736x/aa/60/a5/aa60a56d68c373768af4ffb453c8f589.jpg",
        "https://i.pinimg.com/736x/63/52/09/635209cae217e0ad10a5c85f8aafa818.jpg",
        "https://i.pinimg.com/736x/42/2e/fe/422efea0c919cfb97aa0132ad568d743.jpg",
        "https://i.pinimg.com/736x/f2/e9/b9/f2e9b93a9600dd1d54968fa6f41185b4.jpg",
        "https://i.pinimg.com/736x/70/68/0f/70680fd7ce268d7be2f71dd72426937e.jpg",
        "https://i.pinimg.com/736x/fd/e9/7b/fde97b8da68b5d39214595945eb6537f.jpg",
        "https://i.pinimg.com/736x/62/5a/dd/625add34ff93287ab3c820eec1a03faa.jpg",
        "https://i.pinimg.com/736x/fe/0b/08/fe0b0890e793bf30de01713a19f16a9f.jpg",
        "https://i.pinimg.com/736x/ce/1e/62/ce1e6287c1f2f4d78457b8861fca98e1.jpg",
        "https://i.pinimg.com/736x/f5/fb/ed/f5fbed717b036633b012aac055d340ed.jpg",
        "https://i.pinimg.com/736x/a4/be/07/a4be07e455c83f29f45316d3db89d75e.jpg",
        "https://i.pinimg.com/736x/a4/4d/00/a44d00cdffdb49f5b1e9347c98fd7210.jpg",
        "https://i.pinimg.com/736x/13/16/c6/1316c6635095b9cb1f02b1a29486888c.jpg",
        "https://i.pinimg.com/736x/65/bb/ce/65bbceb6542ab4b2b61df15fb9c3b47f.jpg",
        "https://i.pinimg.com/736x/e3/c0/61/e3c06153388e1ebd2c1f4a75cf49afe0.jpg",
        "https://i.pinimg.com/736x/b5/2c/4c/b52c4c071848911d4689e6caa62f9142.jpg",
        "https://i.pinimg.com/736x/23/92/a6/2392a62dbb41b702c4fccde0a1187930.jpg",
        "https://i.pinimg.com/736x/2e/ce/a9/2ecea934f6f0aed69960e1085449a8ab.jpg",
        "https://i.pinimg.com/736x/e8/7f/e3/e87fe32c9e87259a5355252f0dcaa659.jpg",
        "https://i.pinimg.com/736x/d9/ba/f7/d9baf733f96fa35bacf5b5a35237ef17.jpg",
        "https://i.pinimg.com/736x/3a/81/8a/3a818a6e8327e1a3d45368ea74e4b3d1.jpg",
        "https://i.pinimg.com/736x/e9/cd/7f/e9cd7f47d242dc339c590710d9524b32.jpg",
        "https://i.pinimg.com/736x/76/96/ca/7696cabd8b612934d374afe2ee47c04d.jpg",
        "https://i.pinimg.com/736x/6d/a4/e8/6da4e8bb9e5e8430e549bb92c66e6150.jpg",
        "https://i.pinimg.com/736x/f5/97/27/f5972776719d91f68e1e6487dfe87ac2.jpg",
        "https://i.pinimg.com/736x/b4/3f/59/b43f59f946fc5a022233e0a637318a97.jpg",
        "https://i.pinimg.com/736x/a5/14/bf/a514bf43098e1e8385d13ad30d325cb0.jpg",
        "https://i.pinimg.com/736x/a0/c9/05/a0c905d64aa6d9f32a6dcfc73c3bb48b.jpg",
        "https://i.pinimg.com/736x/3e/54/c6/3e54c6dbcde596cebd6e0c735c36c742.jpg",
        "https://i.pinimg.com/736x/0a/29/50/0a2950b9bf6cb7fe970b8809f1f77b24.jpg",
        "https://i.pinimg.com/736x/7f/c2/28/7fc22897dc1dc13ad874fa08d2fc6315.jpg",
        "https://i.pinimg.com/736x/fe/7f/fc/fe7ffcccb04ee43eb5323ea6e28f4ba8.jpg",
        "https://i.pinimg.com/736x/6d/33/2a/6d332a38528f361709a6eed52b1d5d89.jpg",
        "https://i.pinimg.com/736x/7f/4f/fc/7f4ffc6768a8d47e3d35bedaba16d090.jpg",
        "https://i.pinimg.com/736x/c8/0d/98/c80d98f03c0036ad7807f1f369af5a00.jpg",
        "https://i.pinimg.com/736x/b3/1c/54/b31c543a85eec7e775c0e200f3c8f669.jpg",
        "https://i.pinimg.com/736x/7c/50/1c/7c501c4481f81bce9ec5432ca02782fc.jpg",
        "https://i.pinimg.com/736x/e0/52/45/e0524524dfd506c4c3de66ee62d3b57d.jpg",
        "https://i.pinimg.com/736x/5e/22/68/5e226888cb84549790b8ef63a00c4942.jpg",
        "https://i.pinimg.com/736x/a8/c1/c7/a8c1c715569e534d7239a1c3ea2ea86a.jpg",
        "https://i.pinimg.com/736x/9f/9e/a1/9f9ea1509502a9377161bd80a69dc31f.jpg",
        "https://i.pinimg.com/736x/4f/d7/96/4fd796621ab962ac48841acf97782d01.jpg",
        "https://i.pinimg.com/736x/89/d4/4c/89d44c552b632c58e32dcfeea6348cf5.jpg",
        "https://i.pinimg.com/736x/84/30/eb/8430ebcbde58a5d804a5a3aa6763291d.jpg",
        "https://i.pinimg.com/736x/c1/39/76/c13976c1d5acc4d320df2a297deff7f6.jpg",
        "https://i.pinimg.com/736x/02/c8/61/02c86114ca0468c8be568b42236fc033.jpg",
        "https://i.pinimg.com/736x/97/ea/02/97ea02c9d1b88e9d2c164b02869bd126.jpg",
        "https://i.pinimg.com/736x/9b/45/29/9b4529bac23e07931a374005ba2d7cb9.jpg",
        "https://i.pinimg.com/736x/fa/a1/16/faa1165da75b28053ff676cb0456fef0.jpg",
        "https://i.pinimg.com/736x/23/75/c1/2375c1c65e72e31cdd096c85e6af2735.jpg",
        "https://i.pinimg.com/736x/50/12/4e/50124e7ab95d66986927aea47797ba84.jpg",
        "https://i.pinimg.com/736x/e0/58/1d/e0581d38c35374518c63dcb6adb48bfa.jpg",
        "https://i.pinimg.com/736x/dc/79/bb/dc79bbaccb348f8e63590440f094e0ee.jpg",
        "https://i.pinimg.com/736x/84/7c/9b/847c9b47ee121158c45dec4733314efe.jpg",
        "https://i.pinimg.com/736x/54/83/c1/5483c10e3240e18da8b0443f486aaf87--muslim-girls-abaya-fashion.jpg",
        "https://i.pinimg.com/736x/6d/a5/37/6da5378e6271e5a7278bd04eb1a0273e.jpg",
        "https://i.pinimg.com/736x/b6/e0/10/b6e010632416823e0ce338a970d10eb9--korean-street-fashion-summer-ulzzang-fashion-summer.jpg",
        "https://i.pinimg.com/736x/1e/a3/72/1ea3722b6c6f0eb932358da6ad08e15e.jpg",
        "https://i.pinimg.com/736x/18/27/d4/1827d4c92b4db9b0fef3d771f92b119b.jpg",
        "https://i.pinimg.com/736x/83/c2/19/83c219e7a2d06bcda64bab9c3a7042d3.jpg",
        "https://i.pinimg.com/736x/d3/13/1a/d3131adba01d4df1a1b86567e0d42d1a.jpg",
        "https://i.pinimg.com/736x/db/12/0d/db120d58dc7b349282340c457776b4ae.jpg",
        "https://i.pinimg.com/736x/a2/f4/18/a2f418be0e9bfa6b92d3ae174e846166.jpg",
        "https://i.pinimg.com/736x/29/6c/81/296c81d704c772fbd4332edc97be2c0f.jpg",
        "https://i.pinimg.com/736x/56/31/21/563121db37de8f2e091ab3b3826cd6d2.jpg",
        "https://i.pinimg.com/736x/86/41/df/8641df492bfb63b5974e70b863267baa.jpg",
        "https://i.pinimg.com/736x/59/cb/cf/59cbcf435d6df207e7ddc89cc69553b2.jpg",
        "https://i.pinimg.com/736x/66/34/23/6634233d0f4d7dd23eb2985882139004.jpg",
        "https://i.pinimg.com/736x/75/7e/58/757e58566697863a05c814f8069fc1c2.jpg",
        "https://i.pinimg.com/736x/a5/24/ff/a524ffb4d6a9c5567ecd2a65c5d2b3a8.jpg",
        "https://i.pinimg.com/736x/bf/92/ea/bf92eaff1b51d0974740cdb34c151a4c.jpg",
        "https://i.pinimg.com/736x/5d/9c/78/5d9c787cb469dfb0565165af8d660b5f.jpg",
        "https://i.pinimg.com/736x/e2/f1/ed/e2f1ed1004d5cb6d2bff59ac9da27094.jpg",
        "https://i.pinimg.com/736x/ae/b1/39/aeb13917eb18ae7259390ad3b18c66b9.jpg",
        "https://i.pinimg.com/736x/77/46/a7/7746a7f133cde842f444c5e8e5e4cf60.jpg",
        "https://i.pinimg.com/736x/55/99/ae/5599ae1a0d70811122a0ce7a274f8696.jpg",
        "https://i.pinimg.com/736x/45/d6/3b/45d63b77a4756d9a456f31a95d3be3a8.jpg",
        "https://i.pinimg.com/736x/93/0f/99/930f998f4e2e96092bb2a797b7d3f5b6.jpg",
        "https://i.pinimg.com/736x/f9/47/fc/f947fc6ea4503c6e69b81b9af7223864.jpg",
        "https://i.pinimg.com/736x/66/a2/1f/66a21f4e621f0baae799371f2b1ee9c1.jpg",
        "https://i.pinimg.com/736x/4b/86/77/4b8677149296fb75b0eca577b2c2b9cf.jpg",
        "https://i.pinimg.com/736x/27/7c/c7/277cc778d89f71923b65cbf0ae147ac8.jpg",
        "https://i.pinimg.com/736x/2f/1c/21/2f1c212f469aae1ff161e6338b1922c4.jpg",
        "https://i.pinimg.com/736x/a2/71/71/a27171487ab8a025c8625499f8524020.jpg",
        "https://i.pinimg.com/736x/47/ba/89/47ba89128874c8ea97a20bfab0da6944.jpg",
        "https://i.pinimg.com/736x/29/c5/a4/29c5a496e11f09457b4d7ccf928cb650.jpg",
        "https://i.pinimg.com/736x/b1/0f/8f/b10f8fa1ab8f5ee49ed27a59f34da0d2.jpg",
        "https://i.pinimg.com/736x/c7/fb/3f/c7fb3f45c1aa6989ce715b2ad16bd282.jpg",
        "https://i.pinimg.com/736x/f3/fa/b8/f3fab8cc2c96abf9736d01081f97def3.jpg",
        "https://i.pinimg.com/736x/ab/03/40/ab0340a6f30bff7b4ed6cea51a796137.jpg",
        "https://i.pinimg.com/736x/4d/95/26/4d952649960c5e39805a8319cddb745e.jpg",
        "https://i.pinimg.com/736x/54/8c/2b/548c2b7dad62bc71861ab2fdc3e7cfca.jpg",
        "https://i.pinimg.com/736x/34/ce/d5/34ced574c44287553d9dd2efddd0a283.jpg",
        "https://i.pinimg.com/736x/45/72/1b/45721b5c502f9ec89c81cd3413580bd8.jpg",
        "https://i.pinimg.com/736x/a4/d6/a0/a4d6a0d96400ff5703c484bfef5baa15.jpg",
        "https://i.pinimg.com/736x/97/44/d8/9744d8cdfc383d78595696515a0b1151.jpg",
        "https://i.pinimg.com/736x/5c/96/90/5c9690d1bbec45f87da83eb456b2adff.jpg",
        "https://i.pinimg.com/736x/f9/d1/8f/f9d18fa7c5a844a033ad35fd26660045.jpg",
        "https://i.pinimg.com/736x/06/15/3e/06153e91ada55b060107b1a49f15bb1f.jpg",
        "https://i.pinimg.com/736x/82/43/34/82433456c014c95ed29617ccb1dbcb22.jpg",
        "https://i.pinimg.com/736x/92/53/be/9253be6ece9413894dbf2703c8ebe79f--asian-makeup-korean-makeup.jpg",
        "https://i.pinimg.com/736x/81/83/94/81839433c2a8a3c42306bfc4e301bd26.jpg",
        "https://i.pinimg.com/736x/a5/f1/8c/a5f18ce15b8cfb9f36487c3a0c0f7058.jpg",
        "https://i.pinimg.com/736x/2b/36/b6/2b36b6d8e369c71256132a3b9a4703c6.jpg",
        "https://i.pinimg.com/736x/b1/be/cb/b1becbb8dc57a4569ecb8123a40ff5ef.jpg",
        "https://i.pinimg.com/736x/18/d6/ed/18d6ed16b682c9a45cbb215b47bd4b7c.jpg",
        "https://i.pinimg.com/736x/b6/43/9c/b6439c6e6d0229d113bee9da3db971e3.jpg",
        "https://i.pinimg.com/736x/d9/eb/4e/d9eb4e2a6cc263c3f3ee66c36ca0e2ae.jpg",
        "https://i.pinimg.com/736x/7b/b2/10/7bb210961a195b49768dedf123a065a2.jpg",
        "https://i.pinimg.com/736x/b6/e9/33/b6e9337331b6b9ab4be8f4c91588936c.jpg",
        "https://i.pinimg.com/736x/3b/3a/48/3b3a48c267885fd50cf9d59cc178c429.jpg",
        "https://i.pinimg.com/736x/85/9c/24/859c247fce5c3ed41290ef942cc2b178.jpg",
        "https://i.pinimg.com/736x/b4/f9/07/b4f9077c8a652eea54e168c0ff03315f.jpg",
        "https://i.pinimg.com/736x/a9/35/cd/a935cdf467873e8e22794af172e0ffeb.jpg",
        "https://i.pinimg.com/736x/e1/7f/51/e17f51e79d2a341875db51105995cb1b.jpg",
        "https://i.pinimg.com/736x/2f/e4/32/2fe432f4aeb9d1903377967799a1ac90.jpg",
        "https://i.pinimg.com/736x/fc/9c/24/fc9c24da39736b61cc64de682c56763f.jpg",
        "https://i.pinimg.com/736x/f9/73/7a/f9737a51195e6d8ff9742887642652f7.jpg",
        "https://i.pinimg.com/736x/38/bf/b5/38bfb590eac24d625637ffc69182aa25.jpg",
        "https://i.pinimg.com/736x/78/56/1b/78561b362965e9cee110642292312b05.jpg",
        "https://i.pinimg.com/736x/30/78/95/3078959e00b2461679525519809eefea.jpg",
        "https://i.pinimg.com/736x/fe/d7/a8/fed7a8645997de9451238c3494287ebc.jpg",
        "https://i.pinimg.com/736x/07/f8/4d/07f84d0a8f17118cbb5949bb9758e9aa.jpg",
        "https://i.pinimg.com/736x/34/3c/45/343c450793b915ba18c7d9d2722cbf6f.jpg",
        "https://i.pinimg.com/736x/65/b4/ab/65b4abe30676598edd2430403f726f27.jpg",
        "https://i.pinimg.com/736x/85/e0/5c/85e05c49ca7ed096f0022bd440aaf087.jpg",
        "https://i.pinimg.com/736x/fa/f5/20/faf5207a3cb2bfa4b947afbc2c2cfee4.jpg",
        "https://i.pinimg.com/736x/49/ae/0e/49ae0e242b201057198c53ef29c3822e.jpg",
        "https://i.pinimg.com/736x/34/6a/50/346a5013e5785a2523e989084b147f70.jpg",
        "https://i.pinimg.com/736x/29/28/5f/29285f30f034ce2d1230533be6266dd4.jpg",
        "https://i.pinimg.com/736x/66/5e/8b/665e8b9e61464346fa29d54844a18282.jpg",
        "https://i.pinimg.com/736x/16/e3/af/16e3afd4c95621b338429369a685af10.jpg",
  "https://i.pinimg.com/736x/61/b1/37/61b13777b2496b37ac90dc04208c1e77.jpg"
]
global.gambar2 = [
  'https://cdn.discordapp.com/attachments/770948564947304448/770950434180956160/004-7FVbFKsy0Z0.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/770950436122525716/3d763900d18610184bdf6cc30102150f.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/770950437880856586/3ec23da409a88cbf4bc7daaaf9f50a3d.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/770950439759380520/3f5a759d1dc69dd4ba188ec91c13bf15.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374076270215168/mogami_yoshiaki_sengoku_collection_drawn_by_r44__sample-8869386742f18651f27b9844edbf8487.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374106959544328/0d8f82d2190ab34a58dfdf70379d48bd.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374111305629696/0a35ad05c6d3d2dcce8ee41eafc1c1da.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374110911234088/00ceb0c2-a234-4489-aaf3-fd92d702dec4.gif',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374114480455750/0a748ce5-fa8d-4893-ac86-21100d4d8111.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374115902717952/0a823293ae6d73a5a551ed96d395c085.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374115902717952/0a823293ae6d73a5a551ed96d395c085.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374197708554250/01737-B-z634ccruw.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374561265713192/435-RqgSoMmr39U.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374616014225458/446-tm6e2RNhOTM.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374643557695509/443-K2Hxy9c9FA.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374649732104212/444-BpA5g5jM_hQ.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374712139415622/431-372ilODZtDw.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374715062452224/00432-I0z-TRhK0dA.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374715691860008/432-99ejYgB_8EI.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374719425445918/00433-D5MhVncwM40.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374725652938812/434-O2p1kFgcJXM.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374729382723594/435-RqgSoMmr39U.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374735849816074/436-WNx39AwbeQ4.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374742380609636/437-7jsAQbZCDMQ.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374854036783124/429-FiCsrief79Q.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374855333085194/418-WVRNSuH_xb0.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374859187257424/419-PE_QlfkmVUQ.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374863348662282/420-VAmqHHHKDo.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374867966590996/421-Rwe6_Vfq3DM.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374871719837746/422_BIuU9h5cfI.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374878115889152/423-JIgerUfCsa4.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374906642399252/423-U9pYBn6WlKQ.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374914166587392/424-Pj94NODjZoE.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374917651267624/424-qdfkiW-FP8.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374927751807016/425-FqG0DXNCF_I.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374935717052476/426-5x4J4OuuFDQ.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374940171665446/426-drQcdvVsNnQ.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374948978524161/427-YLirbUpKQeY.jpg',
  'https://cdn.discordapp.com/attachments/770948564947304448/771374956008833045/428-AAiKa5S2XDM.jpg'
]
global.hwaifu2 = [
"https://telegra.ph/file/f34d76df4a2065af1a5ba.jpg",
"https://telegra.ph/file/05c1b22ee83bcd7723b4d.jpg",
"https://telegra.ph/file/1d886f66a44871205335f.jpg",
"https://telegra.ph/file/54d19a9094dc509370bf9.jpg",
"https://telegra.ph/file/e649475bcde78a9977ee5.jpg",
"https://telegra.ph/file/32ba20b6139b129c559c8.jpg",
"https://telegra.ph/file/948434cda49e4af5d9f11.jpg",
"https://telegra.ph/file/6f353c68533283fe79871.jpg",
"https://telegra.ph/file/de268ca9b01101acf2b8a.jpg",
"https://telegra.ph/file/fc6c5b2ae9a20c4256e7f.jpg",
"https://telegra.ph/file/efb70bb0988640f841742.jpg",
"https://telegra.ph/file/77d03fff530a2bcff3bf7.jpg",
"https://telegra.ph/file/6e4623464a659dd8d902b.jpg",
"https://telegra.ph/file/685aa39f0cb0f2c4fd85b.jpg",
"https://telegra.ph/file/10454b9ad693e1eefea58.jpg",
"https://telegra.ph/file/7de8ce5c290c3d8be0856.jpg",
"https://telegra.ph/file/8d7c4eadb7a4722747074.jpg",
"https://telegra.ph/file/ccc5f8eaac0f30919ef6c.jpg",
"https://telegra.ph/file/95f4b43439d7888f15ea5.jpg",
"https://telegra.ph/file/9c2a750db555bd2fad1f3.jpg",
"https://telegra.ph/file/efc5f7e637744fd6bfec2.jpg",
"https://telegra.ph/file/3a5231aade245665633bd.jpg",
"https://telegra.ph/file/2ecfc76feb26ec1eab99b.jpg",
"https://telegra.ph/file/dabb70983b4e833d98344.jpg",
"https://telegra.ph/file/75193a893e38fc580afe6.jpg",
"https://telegra.ph/file/217aa0f4ec76273808aa4.jpg",
"https://telegra.ph/file/8a35d3446b97ae22c7b23.jpg",
"https://telegra.ph/file/092df720701575a7ceaaa.jpg",
"https://telegra.ph/file/a65184a676cd648de34c3.jpg",
"https://telegra.ph/file/180e28807e78419d45537.jpg",
"https://telegra.ph/file/140eff27be983e0cd6781.jpg",
"https://telegra.ph/file/1581b791e16d0029e16b5.jpg",
"https://telegra.ph/file/6a4b36372b4f265bae3bc.jpg",
"https://telegra.ph/file/093caff422f194f00bc6c.jpg",
"https://telegra.ph/file/2294b7ab49eca8a8046b2.jpg",
"https://telegra.ph/file/869224d1c417e8b5c8ff1.jpg",
"https://telegra.ph/file/a78443f0ee887f46808d7.jpg",
"https://telegra.ph/file/1889878933264d16c58bf.jpg",
"https://telegra.ph/file/735aeb47d9c4aa87aaaf3.jpg",
"https://telegra.ph/file/fcf861516db09dda164e0.jpg",
"https://telegra.ph/file/355d96d7e06d109435f67.jpg",
"https://telegra.ph/file/a3bd959e8cf3131be2213.jpg",
"https://telegra.ph/file/5d908f4a17515a15c6202.jpg",
"https://telegra.ph/file/8902f4fc550727a62e99f.jpg",
"https://telegra.ph/file/6a6a40e924c16a8f0de03.jpg",
"https://telegra.ph/file/b035d3038a0b124f1d846.jpg",
"https://telegra.ph/file/9d475f7852bf6f6193c80.jpg",
"https://telegra.ph/file/872c360a7104d86752650.jpg",
"https://telegra.ph/file/f6bbb53620374257bfa51.jpg",
"https://telegra.ph/file/9b76375f3869440818d57.jpg",
"https://telegra.ph/file/a78443f0ee887f46808d7.jpg",
"https://telegra.ph/file/805a37b1e9a963e7d7ecf.jpg",
"https://telegra.ph/file/f9c4d97477b647cf57a2b.jpg",
"https://telegra.ph/file/b6905b77e6c7732592a13.jpg",
"https://telegra.ph/file/9f82c432d0ba4cfffda9a.png",
"https://telegra.ph/file/484083949d4bfd763b8cf.jpg",
"https://telegra.ph/file/2b71a8d46d29351479fbc.jpg",
"https://telegra.ph/file/ae610571b62b5ab876e9c.jpg",
"https://telegra.ph/file/cc8255d5b989eef587af2.jpg",
"https://telegra.ph/file/30d2e7375996abd9cfee3.jpg",
"https://telegra.ph/file/78980c90c44a95a1d30fa.jpg",
"https://telegra.ph/file/2ac5d8ccf23e73eaa5bfa.jpg",
"https://telegra.ph/file/14ae0ba2da77d74e6b80c.jpg",
"https://telegra.ph/file/b6905b77e6c7732592a13.jpg",
"https://telegra.ph/file/9da45a352eb4c40e5d641.jpg",
"https://telegra.ph/file/59e78846ee365975ee6e3.jpg",
"https://telegra.ph/file/1bf7dee46b83eb4c41d7d.jpg",
"https://telegra.ph/file/0525a7929f819cb8278f3.jpg",
"https://telegra.ph/file/df4680f51f1da37f0e5de.jpg",
"https://telegra.ph/file/222c96d6f5cfdec4cc25a.jpg",
"https://telegra.ph/file/f34d76df4a2065af1a5ba.jpg",
"https://telegra.ph/file/05c1b22ee83bcd7723b4d.jpg",
"https://telegra.ph/file/1d886f66a44871205335f.jpg",
"https://telegra.ph/file/54d19a9094dc509370bf9.jpg",
"https://telegra.ph/file/e649475bcde78a9977ee5.jpg",
"https://telegra.ph/file/32ba20b6139b129c559c8.jpg",
"https://telegra.ph/file/948434cda49e4af5d9f11.jpg",
"https://telegra.ph/file/6f353c68533283fe79871.jpg",
"https://telegra.ph/file/de268ca9b01101acf2b8a.jpg",
"https://telegra.ph/file/fc6c5b2ae9a20c4256e7f.jpg",
"https://telegra.ph/file/efb70bb0988640f841742.jpg",
"https://telegra.ph/file/77d03fff530a2bcff3bf7.jpg",
"https://telegra.ph/file/6e4623464a659dd8d902b.jpg",
"https://telegra.ph/file/685aa39f0cb0f2c4fd85b.jpg",
"https://telegra.ph/file/10454b9ad693e1eefea58.jpg",
"https://telegra.ph/file/7de8ce5c290c3d8be0856.jpg",
"https://telegra.ph/file/8d7c4eadb7a4722747074.jpg",
"https://telegra.ph/file/ccc5f8eaac0f30919ef6c.jpg",
"https://telegra.ph/file/95f4b43439d7888f15ea5.jpg",
"https://telegra.ph/file/9c2a750db555bd2fad1f3.jpg",
"https://telegra.ph/file/efc5f7e637744fd6bfec2.jpg",
"https://telegra.ph/file/3a5231aade245665633bd.jpg",
"https://telegra.ph/file/2ecfc76feb26ec1eab99b.jpg",
"https://telegra.ph/file/dabb70983b4e833d98344.jpg",
"https://telegra.ph/file/75193a893e38fc580afe6.jpg",
"https://telegra.ph/file/217aa0f4ec76273808aa4.jpg",
"https://telegra.ph/file/8a35d3446b97ae22c7b23.jpg",
"https://telegra.ph/file/092df720701575a7ceaaa.jpg",
"https://telegra.ph/file/a65184a676cd648de34c3.jpg",
"https://telegra.ph/file/180e28807e78419d45537.jpg",
"https://telegra.ph/file/140eff27be983e0cd6781.jpg",
"https://telegra.ph/file/1581b791e16d0029e16b5.jpg",
"https://telegra.ph/file/6a4b36372b4f265bae3bc.jpg",
"https://telegra.ph/file/093caff422f194f00bc6c.jpg",
"https://telegra.ph/file/2294b7ab49eca8a8046b2.jpg",
"https://telegra.ph/file/869224d1c417e8b5c8ff1.jpg",
"https://telegra.ph/file/a78443f0ee887f46808d7.jpg",
"https://telegra.ph/file/1889878933264d16c58bf.jpg",
"https://telegra.ph/file/735aeb47d9c4aa87aaaf3.jpg",
"https://telegra.ph/file/fcf861516db09dda164e0.jpg",
"https://telegra.ph/file/355d96d7e06d109435f67.jpg",
"https://telegra.ph/file/f1db29ed188159d14fc44.jpg",
"https://telegra.ph/file/d2f5e2aca7f2c8ec732f6.jpg",
"https://telegra.ph/file/8d20d271911c64d1c4acf.jpg",
"https://telegra.ph/file/ee5faa155d540e189687f.jpg",
"https://telegra.ph/file/305301b1bc211a02bffce.jpg",
"https://telegra.ph/file/d56bfca798e704148c592.jpg",
"https://telegra.ph/file/433f5544a8de58b766248.jpg",
"https://telegra.ph/file/adf02aabeeac135c40333.jpg",
"https://telegra.ph/file/22fc7baa39472b570c23c.jpg",
"https://telegra.ph/file/22fc7baa39472b570c23c.jpg",
"https://telegra.ph/file/ac28e289077fa9bea1d72.jpg",
"https://telegra.ph/file/cf387acdc48d2d65035b9.jpg",
"https://telegra.ph/file/7a551521c4a620e6e2448.jpg",
"https://telegra.ph/file/17d77676cafe1adb22951.jpg",
"https://telegra.ph/file/6afbd19d5c5b61e715467.jpg",
"https://telegra.ph/file/c32176197b2809065004f.jpg",
"https://telegra.ph/file/496995500a75fcbbeec9d.jpg",
"https://telegra.ph/file/ac05c193e77dc1eb42536.jpg",
"https://telegra.ph/file/a43afff9eb761b45c7a44.jpg",
"https://i.pinimg.com/originals/ed/34/f8/ed34f88af161e6278993e1598c29a621.jpg",
"https://i.pinimg.com/originals/85/4d/bb/854dbbd30304cd69f305352f0183fad0.jpg",
"https://i.pinimg.com/originals/32/2c/a4/322ca456fa2cdec4b717895a65adfa8d.jpg",
"https://i.pinimg.com/originals/f2/dd/cc/f2ddccd5a1b89d2302cf75c6520c58dd.png",
"https://i.pinimg.com/originals/aa/6b/df/aa6bdf98cbc9e1fc741c36682fa3e838.jpg",
"https://i.pinimg.com/originals/88/46/88/884688def830c43648f88154836a8b05.jpg",
"https://i.pinimg.com/originals/57/d9/20/57d920d58533915850b431bd0b8e1f1d.jpg",
"https://i.pinimg.com/originals/46/ad/05/46ad0505d33a2c2359f84ed9b867a58c.jpg",
"https://i.pinimg.com/originals/23/b7/fb/23b7fb922770e139a2a57b1a443a2180.jpg",
"https://i.pinimg.com/originals/46/79/25/467925d52634fd098ab6890a23c33f30.jpg",
"https://i.pinimg.com/originals/a4/a1/74/a4a1740e565f4205eb3f700e1936e064.jpg",
"https://i.pinimg.com/originals/f9/8d/2c/f98d2c3f64e50ba6c8efd9fdc7cf0093.png",
"https://i.pinimg.com/originals/29/a4/b4/29a4b4573f993d7d6abb45843f529892.jpg",
"https://i.pinimg.com/originals/40/de/84/40de84ce2ee376d8fae8ff5863d6edb0.jpg",
"https://i.pinimg.com/originals/b6/f5/b7/b6f5b7d59fd4f332b3820db38612a5a0.jpg",
"https://i.pinimg.com/originals/94/38/6d/94386d3c23f509dbc30341fed0363a07.jpg",
"https://i.pinimg.com/originals/b5/94/ef/b594ef0774d29f5a05cd182994aa354e.jpg",
"https://i.pinimg.com/originals/0f/ed/3f/0fed3f4c456158c506d88f5867ca93d2.jpg",
"https://i.pinimg.com/originals/1b/7a/a8/1b7aa80191b83b888e9ea6042f090763.jpg",
"https://i.pinimg.com/originals/72/7a/08/727a08cdf67b62c2ba49e7308c09a1cd.jpg",
"https://i.pinimg.com/originals/86/93/75/8693757390b9d5b83fb8e40ff9ea876f.jpg",
"https://i.pinimg.com/originals/5f/79/71/5f79713647b3e99a787ee7483715c1eb.jpg",
"https://i.pinimg.com/originals/b8/b3/f3/b8b3f397fead38a988174df75d481202.png",
"https://i.pinimg.com/originals/7a/e0/55/7ae055891f8200cd62ec76a40d47118d.jpg",
"https://i.pinimg.com/originals/bc/9b/81/bc9b81c63b4844fd1a434d462bdfbd80.png",
"https://i.pinimg.com/originals/22/8b/ca/228bca60a07d72cac953a9c3be542bab.jpg",
"https://i.pinimg.com/originals/41/10/c6/4110c64fc91a1c85de02166f67aff7ad.jpg",
"https://i.pinimg.com/originals/45/11/41/451141522a9086f56efc0da3fdac1957.jpg",
"https://i.pinimg.com/originals/c1/4e/c7/c14ec7dffbc682f78c52ad8a295b8831.jpg",
"https://i.pinimg.com/originals/25/5d/d9/255dd9dde5f44673092a4f15e917759f.jpg",
"https://i.pinimg.com/originals/1f/95/15/1f95156c3d8e2b339a22b3bad2f69a8a.png",
"https://i.pinimg.com/originals/bb/1a/12/bb1a1249dbc73736ab534fdd52bdc74c.jpg",
"https://i.pinimg.com/originals/d5/58/a7/d558a745f2452d851d480025ab341537.jpg",
"https://i.pinimg.com/originals/e7/00/0e/e7000e7e72c1b37ea7a4c780182d05d8.jpg",
"https://i.pinimg.com/originals/9e/53/a9/9e53a92ee711d979b9bdbb6212115fe0.jpg",
"https://i.pinimg.com/originals/c6/16/d9/c616d9a871ed3cd9fb6a46efb7f92d95.jpg",
"https://i.pinimg.com/originals/ac/f0/29/acf029047efffe57999fa876554cbf1d.jpg",
"https://i.pinimg.com/originals/ae/86/3b/ae863b64ca579f05008dbf027b04988f.jpg",
"https://i.pinimg.com/originals/d5/65/43/d56543a959da518e08012b4db93747bb.jpg",
"https://i.pinimg.com/originals/ed/3c/e2/ed3ce276ca71e5bfec1cf2fbfc5561e1.jpg",
"https://i.pinimg.com/originals/66/30/37/663037f00539f3bc1dbd3efeae0d700b.jpg",
"https://i.pinimg.com/originals/63/6b/7b/636b7bd0e1df03f0bf72c494cedd6f07.png",
"https://i.pinimg.com/originals/db/a4/13/dba413518c0a470a5e81cafa431281da.jpg",
"https://i.pinimg.com/originals/3b/d9/aa/3bd9aa880d23dc3262e119ca09345e99.jpg",
"https://i.pinimg.com/originals/ef/90/4e/ef904eda01a996e5a9d557a55db6da0f.png",
"https://i.pinimg.com/originals/fb/f7/a9/fbf7a92af75577e33a564ce490154c8f.jpg",
"https://i.pinimg.com/originals/16/92/89/1692897136ac3688ab9ccdbb0e54fb21.jpg",
"https://i.pinimg.com/originals/fc/51/4e/fc514e2f4c23eb96721611b483edc28c.jpg",
"https://i.pinimg.com/originals/bb/a4/98/bba49848bc4369333f4128b62fc64258.jpg",
"https://i.pinimg.com/originals/67/a7/54/67a754077a1ffc75c25b3c7bb04d2258.png",
"https://i.pinimg.com/originals/57/d9/20/57d920d58533915850b431bd0b8e1f1d.jpg",
"https://i.pinimg.com/originals/83/e5/71/83e5710c42b9e8b9e1a4b6381c4535fe.jpg",
"https://i.pinimg.com/originals/88/46/88/884688def830c43648f88154836a8b05.jpg",
"https://i.pinimg.com/originals/32/2c/a4/322ca456fa2cdec4b717895a65adfa8d.jpg",
"https://i.pinimg.com/originals/42/88/f1/4288f17ee25b909430fb7e707d961d0b.jpg",
"https://i.pinimg.com/originals/16/14/9c/16149c94a7c0f753230b1edbd03ab3e6.jpg",
"https://i.pinimg.com/originals/7f/f5/46/7ff546b38e2969e578e697c44944b74f.jpg",
"https://i.pinimg.com/originals/6d/bc/61/6dbc616311268a25b0ee0e1bd4de13b6.jpg",
"https://i.pinimg.com/originals/60/34/18/603418ea5c35839914a1071e134add8b.jpg",
"https://i.pinimg.com/originals/5f/79/71/5f79713647b3e99a787ee7483715c1eb.jpg",
"https://i.pinimg.com/originals/ed/ea/37/edea37b6f876bfc8f59bbae4d43e26d7.jpg",
"https://i.pinimg.com/originals/94/38/6d/94386d3c23f509dbc30341fed0363a07.jpg",
"https://i.pinimg.com/originals/f6/20/b4/f620b4b1c2aaf096455952465db8a980.jpg",
"https://i.pinimg.com/originals/97/50/73/9750731b4b004da61d44fe01dbe93d85.jpg",
"https://i.pinimg.com/originals/a0/55/41/a055419e96bc61a5990c575af10ba99e.png",
"https://i.pinimg.com/originals/aa/6b/df/aa6bdf98cbc9e1fc741c36682fa3e838.jpg",
"https://i.pinimg.com/originals/c2/4f/75/c24f7518e17faba4bf8908a39be604a6.jpg",
"https://i.pinimg.com/originals/95/bb/2e/95bb2e7c8b71754003d063f39feb232a.jpg",
"https://i.pinimg.com/originals/c4/e4/1d/c4e41d096e7585a7e6245e852ece25c2.jpg",
"https://i.pinimg.com/originals/87/cf/bc/87cfbc189e773ed9294bccfd50a4fbc7.jpg",
"https://i.pinimg.com/originals/7a/3b/e6/7a3be6cf1595fe6764b5b18b46ca576d.jpg",
"https://i.pinimg.com/originals/c5/42/f8/c542f83b992e51c6d2519f07489b1dec.jpg",
"https://i.pinimg.com/originals/96/29/1e/96291e9abbf311b8fc6c8c3f9f8ae059.jpg",
"https://i.pinimg.com/originals/e5/1a/8d/e51a8d35d2b717fa757fa2abf053a2c7.jpg",
"https://i.pinimg.com/originals/47/18/af/4718afcd517c8e7e07cc9dba48b3b770.jpg",
"https://i.pinimg.com/originals/39/2c/cb/392ccb1793c5a23783869994b1ec24b7.jpg",
"https://i.pinimg.com/originals/0f/98/5f/0f985ffbfff2650d6e3ecf8ba0eb574e.jpg",
"https://i.pinimg.com/originals/ab/f9/50/abf950c9aa1c4710437d9acc83078f87.jpg",
"https://i.pinimg.com/originals/f2/dd/cc/f2ddccd5a1b89d2302cf75c6520c58dd.png",
"https://i.pinimg.com/originals/f1/f7/fc/f1f7fca39eba7d64e50749da5406247c.jpg",
"https://i.pinimg.com/originals/71/18/96/711896c067c28814ec9ec9c25d4a3ba9.jpg",
"https://i.pinimg.com/originals/67/a7/54/67a754077a1ffc75c25b3c7bb04d2258.png",
"https://i.pinimg.com/originals/8f/fe/d4/8ffed485ed8b6db07067e452f8399fff.jpg",
"https://i.pinimg.com/originals/db/b6/46/dbb6463c9134591aa79369f325877e03.jpg",
"https://i.pinimg.com/originals/9f/23/1a/9f231a6acc906f95ff3f917211b9abda.png",
"https://i.pinimg.com/originals/b9/a9/66/b9a9669f0fbbe75e780adad301601b43.jpg",
"https://i.pinimg.com/originals/86/ed/26/86ed265f2dbb22a48bbc612f59303508.png",
"https://i.pinimg.com/originals/da/ae/25/daae25409adec418a9b6f6c5dcdecd47.jpg",
"https://i.pinimg.com/originals/a4/6d/fa/a46dfad749d0577366e9ea2db6cc305e.jpg",
"https://i.pinimg.com/originals/09/5b/4d/095b4d0ce48f40eca7ad23e43e85ab9a.jpg",
"https://i.pinimg.com/originals/d9/e1/30/d9e1307a5fbbeb2a267562eab8abc063.jpg",
"https://i.pinimg.com/originals/db/cf/dc/dbcfdc263095906eabf7e06099ebaef0.png",
"https://i.pinimg.com/originals/89/14/0d/89140d3ef976904013f672fea0157b7e.png",
"https://i.pinimg.com/originals/cf/4f/cf/cf4fcf2036f0b5b974f146f2c0ba81db.jpg",
"https://i.pinimg.com/originals/93/62/9e/93629ee9ab27043076bce2b1f22f9193.jpg",
"https://i.pinimg.com/originals/99/6b/c4/996bc4049d632bdbf7d9bc24dc8081f0.png",
"https://i.pinimg.com/originals/f2/6d/35/f26d354b1421546ae993c83f5c7bcfb0.jpg",
"https://i.pinimg.com/originals/25/5d/d9/255dd9dde5f44673092a4f15e917759f.jpg",
"https://i.pinimg.com/originals/08/8f/1d/088f1dc58092b60652e05cc941ee0fbd.jpg",
"https://i.pinimg.com/originals/14/17/dd/1417dd63009eea0b63252076f3b405e6.jpg",
"https://i.pinimg.com/originals/35/04/d5/3504d53c5850b3bddaa6e0e0714ccacb.jpg",
"https://i.pinimg.com/originals/88/46/88/884688def830c43648f88154836a8b05.jpg",
"https://i.pinimg.com/originals/57/d9/20/57d920d58533915850b431bd0b8e1f1d.jpg",
"https://i.pinimg.com/originals/44/39/17/443917c07ffd65caa7d7cd4065fb8571.jpg",
"https://i.pinimg.com/originals/bc/9b/81/bc9b81c63b4844fd1a434d462bdfbd80.png",
"https://i.pinimg.com/originals/4a/e2/74/4ae274c828a2c719bcf9f644106d26cf.jpg",
"https://i.pinimg.com/originals/d0/cb/da/d0cbdaa334fa92f8b09d1c4d1ddc9cd2.jpg",
"https://i.pinimg.com/originals/71/16/31/711631ac52f7809f530e40f230b371a4.jpg",
"https://i.pinimg.com/originals/af/f1/1b/aff11bcfdf946a7bba1687c80515f902.jpg",
"https://i.pinimg.com/originals/46/79/25/467925d52634fd098ab6890a23c33f30.jpg",
"https://i.pinimg.com/originals/ef/90/4e/ef904eda01a996e5a9d557a55db6da0f.png",
"https://i.pinimg.com/originals/a2/e7/73/a2e773fdb7ce0fc99eb123d8a81764ec.jpg",
"https://i.pinimg.com/originals/79/92/ed/7992ed0c9b272654938ea186cc2e3f4a.jpg",
"https://i.pinimg.com/originals/7a/08/c8/7a08c8c22066a142f22928662d9d70aa.jpg",
"https://i.pinimg.com/originals/20/b0/96/20b0962b8c62584fbcd6e7675b4782a4.jpg",
"https://i.pinimg.com/originals/51/0f/8c/510f8cb8f28b8666d560f89e2006d4b1.jpg",
"https://i.pinimg.com/originals/c2/4f/75/c24f7518e17faba4bf8908a39be604a6.jpg",
"https://i.pinimg.com/originals/4e/43/7b/4e437b1bbdee605d833155a97d35bef1.png",
"https://i.pinimg.com/originals/d5/a2/c9/d5a2c9cdfac835518e45b13cfc39819d.jpg",
"https://i.pinimg.com/originals/95/bb/2e/95bb2e7c8b71754003d063f39feb232a.jpg",
"https://i.pinimg.com/originals/16/92/89/1692897136ac3688ab9ccdbb0e54fb21.jpg",
"https://i.pinimg.com/originals/6f/9a/86/6f9a86eb31e7c5bc34cf0d1d130574e0.png",
"https://i.pinimg.com/originals/f0/67/f0/f067f00a885fab47d76d4e5423d54c35.jpg",
"https://i.pinimg.com/originals/4e/9a/7a/4e9a7a196cea58427163313b7db6363e.jpg",
"https://i.pinimg.com/originals/53/4c/6a/534c6a2e65fdb4c52824f94acc5e2195.jpg",
"https://i.pinimg.com/originals/8d/04/9a/8d049a1e6951491b24ea4c364f2459bc.jpg",
"https://i.pinimg.com/originals/22/dc/94/22dc941e60b0ace15d796a94f07d8ba7.jpg",
"https://i.pinimg.com/originals/80/bc/96/80bc968b4dcd939b60ffe2c8b0c54d75.png",
"https://i.pinimg.com/originals/ed/34/f8/ed34f88af161e6278993e1598c29a621.jpg",
"https://i.pinimg.com/originals/9b/36/24/9b36241f4a3b782c05eadb0805ef0dda.png",
"https://i.pinimg.com/originals/22/8b/ca/228bca60a07d72cac953a9c3be542bab.jpg",
"https://i.pinimg.com/originals/57/0e/9b/570e9b1288f1189a22b39c8e24ec957f.jpg",
"https://i.pinimg.com/originals/68/af/17/68af1781a9120a59629d0f774555185f.jpg",
"https://i.pinimg.com/originals/42/88/f1/4288f17ee25b909430fb7e707d961d0b.jpg",
"https://i.pinimg.com/originals/c8/0e/ee/c80eeea7a37d732d5a1b0e60464f9e18.jpg",
"https://i.pinimg.com/originals/1d/08/cb/1d08cbb9d42812984bed54e8291edaec.jpg",
"https://i.pinimg.com/originals/4e/37/02/4e37020a3e69f16cd04b246c2937b979.jpg",
"https://i.pinimg.com/originals/59/8e/bf/598ebf206f5ec366e2e32e8c6e8cffb4.jpg",
"https://i.pinimg.com/originals/cb/ef/94/cbef94975cfed070027c2175a730155d.jpg",
"https://i.pinimg.com/originals/e0/74/f8/e074f8dc647066a9f112533c789c0e42.png",
"https://i.pinimg.com/originals/60/ac/9e/60ac9edf63fcb43e3f00555cb71ae6f2.jpg",
"https://i.pinimg.com/originals/17/16/76/1716760d93dcbf7664380fd81f3133f5.jpg",
"https://i.pinimg.com/originals/a3/70/e1/a370e1f592136a385ac6cb15918d25f1.jpg",
"https://i.pinimg.com/originals/89/ee/ab/89eeabd90e54b2951459f81f51e2c791.jpg",
"https://i.pinimg.com/originals/77/0d/23/770d235d3f6dcd021bda5efdf53cca36.png",
"https://i.pinimg.com/originals/67/a7/54/67a754077a1ffc75c25b3c7bb04d2258.png",
"https://i.pinimg.com/originals/c3/1e/58/c31e58fae7f58af4d643c5a2facd49d7.jpg",
"https://i.pinimg.com/originals/0f/98/5f/0f985ffbfff2650d6e3ecf8ba0eb574e.jpg",
"https://i.pinimg.com/originals/93/0a/5f/930a5fc6f8f6e64e87ac2cc30b8430ac.jpg",
"https://i.pinimg.com/originals/1e/14/22/1e14229be49534cbf3d43b71b1738b80.jpg",
"https://i.pinimg.com/originals/35/04/d5/3504d53c5850b3bddaa6e0e0714ccacb.jpg",
"https://i.pinimg.com/originals/57/d9/20/57d920d58533915850b431bd0b8e1f1d.jpg",
"https://i.pinimg.com/originals/c2/4f/75/c24f7518e17faba4bf8908a39be604a6.jpg",
"https://i.pinimg.com/originals/7f/f5/46/7ff546b38e2969e578e697c44944b74f.jpg",
"https://i.pinimg.com/originals/bc/9b/81/bc9b81c63b4844fd1a434d462bdfbd80.png",
"https://i.pinimg.com/originals/d5/a2/c9/d5a2c9cdfac835518e45b13cfc39819d.jpg",
"https://i.pinimg.com/originals/d7/02/54/d7025401aec66a4baf0fbcbc1054b499.jpg",
"https://i.pinimg.com/originals/95/bb/2e/95bb2e7c8b71754003d063f39feb232a.jpg",
"https://i.pinimg.com/originals/ee/ee/fd/eeeefda1774a2d5dced265c1a2d398d5.jpg",
"https://i.pinimg.com/originals/c3/1e/58/c31e58fae7f58af4d643c5a2facd49d7.jpg",
"https://i.pinimg.com/originals/1f/9c/1d/1f9c1d5f4d2de0b74e81f190ab4f1792.jpg",
"https://i.pinimg.com/originals/7a/3b/e6/7a3be6cf1595fe6764b5b18b46ca576d.jpg",
"https://i.pinimg.com/originals/51/08/53/5108536a4826d3354ac3fe9c3c867cb1.png",
"https://i.pinimg.com/originals/77/cc/bc/77ccbcd52758458669ed5eadf4437111.jpg",
"https://i.pinimg.com/originals/51/0f/8c/510f8cb8f28b8666d560f89e2006d4b1.jpg",
"https://i.pinimg.com/originals/6f/9a/86/6f9a86eb31e7c5bc34cf0d1d130574e0.png",
"https://i.pinimg.com/originals/79/92/ed/7992ed0c9b272654938ea186cc2e3f4a.jpg",
"https://i.pinimg.com/originals/39/2c/cb/392ccb1793c5a23783869994b1ec24b7.jpg",
"https://i.pinimg.com/originals/3b/2c/02/3b2c020665f835b0dfdd74b8cc9ca22d.jpg",
"https://i.pinimg.com/originals/ee/cf/7c/eecf7cc7f65e5d503399cc88f0e6ef6c.jpg",
"https://i.pinimg.com/originals/4e/9a/7a/4e9a7a196cea58427163313b7db6363e.jpg",
"https://i.pinimg.com/originals/8b/f8/46/8bf8468935d529c6383771097381196a.jpg",
"https://i.pinimg.com/originals/f3/5d/ce/f35dce5f6742bd4f30033fe7b51335cc.jpg",
"https://i.pinimg.com/originals/94/a6/69/94a6692d5bd9ba0bbd80ba1e4122b2f9.jpg",
"https://i.pinimg.com/originals/8f/55/04/8f55043dfd9d244f172077bdc0304c6a.png",
"https://i.pinimg.com/originals/89/ee/ab/89eeabd90e54b2951459f81f51e2c791.jpg",
"https://i.pinimg.com/originals/83/5a/2e/835a2e582d1f803f03ab3a3c3e58b694.jpg",
"https://i.pinimg.com/originals/25/5d/d9/255dd9dde5f44673092a4f15e917759f.jpg",
"https://i.pinimg.com/originals/e2/f1/0e/e2f10ead12c9a2d7c0bb29442604f43d.jpg",
"https://i.pinimg.com/originals/f5/2a/09/f52a09910f1cad9b5b01d79a620870dc.jpg",
"https://i.pinimg.com/originals/d9/e1/30/d9e1307a5fbbeb2a267562eab8abc063.jpg",
"https://i.pinimg.com/originals/6a/4d/11/6a4d11cb5bab1466cf1ccb8c6c4f9eb6.jpg",
"https://i.pinimg.com/originals/f3/b7/37/f3b7376c2a574b8619c197bce72d1f63.png",
"https://i.pinimg.com/originals/93/0a/5f/930a5fc6f8f6e64e87ac2cc30b8430ac.jpg",
"https://i.pinimg.com/originals/30/78/75/307875a9132c6e704eec94bc31fd4f71.jpg",
"https://i.pinimg.com/originals/12/fa/7d/12fa7df7ba74ac00d846d8d490f7c8a4.jpg",
"https://i.pinimg.com/originals/68/f6/f3/68f6f37335624f89cda17ab928f51138.jpg",
"https://i.pinimg.com/originals/de/f6/e7/def6e7ce26ad6a1096e8b1ef395a1904.jpg",
"https://i.pinimg.com/originals/cc/17/be/cc17be94cd520baa4722e0ca2329c2e9.jpg",
"https://i.pinimg.com/originals/b3/c5/d1/b3c5d1076a9a48c075c8a92987b03bf3.jpg",
"https://i.pinimg.com/originals/2c/e6/02/2ce6025d9d1736cf3e67db1fd2bdaf35.jpg",
"https://i.pinimg.com/originals/31/07/53/310753699042b254fdfa0472a2675158.jpg",
"https://i.pinimg.com/originals/6b/87/9c/6b879cc29b5df23941dab4f4aafabcbd.jpg",
"https://i.pinimg.com/originals/52/90/0b/52900bab0f969d9d68207f6ad8510882.jpg",
"https://i.pinimg.com/originals/25/7e/db/257edb1b91a127bcf91cc2ea6b29edaf.jpg",
"https://i.pinimg.com/originals/63/6b/7b/636b7bd0e1df03f0bf72c494cedd6f07.png",
"https://i.pinimg.com/originals/8d/ad/58/8dad58f3b258b3d7f2e913cb4561d99f.jpg",
"https://i.pinimg.com/originals/8d/04/9a/8d049a1e6951491b24ea4c364f2459bc.jpg",
"https://i.pinimg.com/originals/fd/21/41/fd21419275236bb153de3c8dcbbf3bf9.jpg",
"https://i.pinimg.com/originals/80/4f/1a/804f1a05f9996c96a2d492b4854b7fd5.jpg"
]
global.flaaa = [
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=', 
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=',
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=crafts-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&text=',
'https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=amped-logo&doScale=true&scaleWidth=800&scaleHeight=500&text=',
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&text=',
'https://www6.flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=sketch-name&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextType=1&fillTextPattern=Warning!&fillColor1Color=%23f2aa4c&fillColor2Color=%23f2aa4c&fillColor3Color=%23f2aa4c&fillColor4Color=%23f2aa4c&fillColor5Color=%23f2aa4c&fillColor6Color=%23f2aa4c&fillColor7Color=%23f2aa4c&fillColor8Color=%23f2aa4c&fillColor9Color=%23f2aa4c&fillColor10Color=%23f2aa4c&fillOutlineColor=%23f2aa4c&fillOutline2Color=%23f2aa4c&backgroundColor=%23101820&text='] 
global.logo = [
  'https://telegra.ph/file/c1599cc2424ec477dba9c.jpg','https://telegra.ph/file/b855baefdec15510c8fdc.jpg','https://telegra.ph/file/49f7b55ddfe2eba3a4e70.jpg','https://telegra.ph/file/9b3e6f0c7e4f4b9dc3832.jpg','https://telegra.ph/file/bf3444292b5c5e43cae2f.jpg','https://telegra.ph/file/067e8dc26b6a7860d23e8.jpg','https://telegra.ph/file/f0dfebc4a7cabdb2f18d4.jpg','https://telegra.ph/file/5e5888813807387170227.jpg','https://telegra.ph/file/85d92052a774e5fff90d3.jpg','https://telegra.ph/file/7359e5d3c60962d3d5638.jpg','https://telegra.ph/file/81466171835a42ceb8ef5.jpg','https://telegra.ph/file/708bd8a7b0faa7f70078b.jpg','https://telegra.ph/file/03d2778acd65eec07774f.jpg','https://telegra.ph/file/ac3e6a46d5097365bee7d.jpg','https://telegra.ph/file/810cb10e72ab1de7567b8.jpg','https://telegra.ph/file/bb2890eb91aac9ea24084.jpg','https://telegra.ph/file/59ff6a1ad944738d10cb5.jpg','https://telegra.ph/file/4edeee22e6981dc65e116.jpg','https://telegra.ph/file/ebf26e276a90ea52eeb03.jpg','https://telegra.ph/file/595ed4cc6d33c85bbb266.jpg','https://telegra.ph/file/20bdc9133add55672465a.jpg','https://telegra.ph/file/a6f5b277d78fdebc59c11.jpg','https://telegra.ph/file/4ba39741593bd18a27414.jpg','https://telegra.ph/file/cfabf1adc3eda83b6bf50.jpg','https://telegra.ph/file/c421cde8c8015f3ff870a.jpg','https://telegra.ph/file/a92efe35f03a5b1380548.jpg','https://telegra.ph/file/20c7e2cc4d48ad96577f7.jpg','https://telegra.ph/file/1d0fad7ae5ee470bf8ec4.jpg','https://telegra.ph/file/73cf2c2af00661dc241b4.jpg','https://telegra.ph/file/c534bda9ddd02d2dfc02c.jpg','https://telegra.ph/file/29b9d63971bca2dbc9def.jpg','https://telegra.ph/file/b70cc42e27ce9fce33760.jpg','https://telegra.ph/file/612277ee5e01346913ed2.jpg','https://telegra.ph/file/a66fe3f4caa11a9884d68.jpg','https://telegra.ph/file/fb6c019fc6d21e3d90e16.jpg','https://telegra.ph/file/ee51a2125297766440dc6.jpg','https://telegra.ph/file/58c13ffc4e9f46e531619.jpg','https://telegra.ph/file/567b6440cc673af7d62c3.jpg','https://telegra.ph/file/1be40b365ab187aea062d.jpg','https://telegra.ph/file/d55722b2eab3c2cd9a636.jpg','https://telegra.ph/file/58696efaa503641dee44d.jpg','https://telegra.ph/file/5fddc12ec1fc965b16e66.jpg','https://telegra.ph/file/2fafa3b5c5dbb0ba5de7f.jpg','https://telegra.ph/file/49883e6a83459ba168480.jpg','https://telegra.ph/file/209fe1c309cb74c8b1671.jpg','https://telegra.ph/file/043996d5f18bd042750c6.jpg','https://telegra.ph/file/761f92f07d43fbcd77e58.jpg','https://telegra.ph/file/63f25862ac7cd6f26e782.jpg','https://telegra.ph/file/3c42b93253ca6063b2be8.jpg']

}}
export default handler 



/* Apa Kabar */
function ThumbUrl() {
    let Turl = pickRandom([
'/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAcACADASIAAhEBAxEB/8QAGAABAQEBAQAAAAAAAAAAAAAABAUGAQP/xAAoEAACAQQCAQMDBQAAAAAAAAABAgMABBEhBRIxBkFRInGxE1JhwdH/xAAWAQEBAQAAAAAAAAAAAAAAAAAAAQL/xAAZEQACAwEAAAAAAAAAAAAAAAAAAQIRITH/2gAMAwEAAhEDEQA/ANNFd9Uml65ZBkDIGdZxWcmbkORVpooCIzvWvzXlytxKbRew6r1zkeCc/wCCn+mL2C44oqBmeMYdTv7H7VqTrhuOkMXtzYylGPVZNOMDYqpeSme6tDFvvhCc6bBoXqSaKa5PUALEMN1+TXLxWt4lWMMYCRJGzbZcgaNFwSxljnYJoePgT9JXnRSA37c+Sfk/FA4xIuMsZJr1Y42VAqiPTOffPyabzlzK98kRb6c7xUq4UXk1qJfDq2QP4OP6qR1B5wJb2V1zLMsKiNCS2/FXOUiVOCIByUEa5A0SNHBp0kCWVkVt8oCuz77pfIW8UvFvCy/QIyBj2wNfiq3QUb0//9k=',
'/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAgACADASIAAhEBAxEB/8QAGAABAQEBAQAAAAAAAAAAAAAABAUDAQL/xAAmEAACAQMDAwQDAAAAAAAAAAABAgMAESEEEjEFEyIVQVFhcZHw/8QAFwEAAwEAAAAAAAAAAAAAAAAAAAEDAv/EABwRAAICAwEBAAAAAAAAAAAAAAECAAMREiExIv/aAAwDAQACEQMRAD8AlGEA5kU/NYSad4nQqwcMcW9q1k6TOG8ZBb7JFO0iDRIVSXa5A3EnP9mk2o8hWNjJUpMepQtcC3Nc1B3OBGcng/FI1SrtJGVB9/ipyxnvMl88/mmnRmFyatzwxPrUpGWcj7ApMbNIO67XZheof6qhoeojSL5xdy3AJxas2AkfIlKWVDkxuCDf3NT9Rui1IEZN+QDXqPqC+ZkG3N1AHP1QJXeZy7tuJpICDKXOrqMT/9k=',
'/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAgACADASIAAhEBAxEB/8QAGgABAAEFAAAAAAAAAAAAAAAABQMBAgQGB//EACoQAAICAgEDAQcFAAAAAAAAAAECAwQAERIFITETBhQiMkFx8DOBkaHR/8QAGAEAAgMAAAAAAAAAAAAAAAAAAwQAAQX/xAAcEQACAgMBAQAAAAAAAAAAAAABAgADERIhQRP/2gAMAwEAAhEDEQA/AD/Q5UqyjjGHChpCu9AjCZoeF5Y6jCU7HEjR+L6j+cWCSTdOhhA/UVR3OJ9K6BFVf3u07MiKWTQ1vX52yO2OewVQ4ZiCFhD6npKzD5kCg6+2TVZKrwFxGvPRABT64hYNazWrz0lKq7MC2yD2HjIb1FVhMqluI7kb/vEvu1baOYU0qRssIroRVhZQ3IKpHjHLUs12WGSFzBGi6Kkggn9s5+bD8eDSMdAAfF4xb2YtrHbljlccHjJHI9tg4xeWxssqtAOGbeCFiVSSdaViT4B/3LeoziKFVKgpJtW+2shS1XJLNPHsnfzL+DKW7FWxWZGmjGhsEMO2ZDDLA9Mb8n//2Q==',
'/9j/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAgACADASIAAhEBAxEB/8QAGAAAAwEBAAAAAAAAAAAAAAAABAUGBwP/xAApEAACAgEDAwMDBQAAAAAAAAABAgMRBAAFIRJBUQYTMRQicUJhgaHx/8QAFgEBAQEAAAAAAAAAAAAAAAAAAAEC/8QAGBEAAwEBAAAAAAAAAAAAAAAAAAERAkH/2gAMAwEAAhEDEQA/AJjFEXu9U5+xf0jvov6+NUZUhoMeaoceNDYUH1OVHDz9x7CyaF8DzxqmwvTuLOjCVclAaZS1Ke+qnBKJTnY8pT3oj8ENwDoXJjh6Fkgax8MPB043PYFgLmETlUFCk6gTXFkaQEEGiKN1WraJDvt8og3HHkLlAsi2wNEdr/vWhRxyQAjr6rPHA1J5nptMbbZ8lsos0QqglAtY/mtOfT24vPtimVSVVii2bNCqsn51hm8vgflCZA05kCpGpfgX8DWeAqVXi5C1k+B/uq/1PmONqZVJjV2Cmu/5/bUg0LwZPtyCmBH4I8jRE0f/2Q=='
])
    return Turl
}

/* Fake Reply */
function Fakes() {
    let Org = pickRandom(["0", "628561122343", "6288906250517", "6282195322106", "6281119568305", "6281282722861", "6282112790446"])
    let Parti = pickRandom([Org + "@s.whatsapp.net", Org + "@c.us"])
    let Remot = pickRandom(["status@broadcast", "120363047752200594@g.us"])
    let Hai = pickRandom(["Apa kabar ", "Halo ", "Hai "])
    let Sarapan = "👋 " + Hai + Pagi()
    let Thum = ThumbUrl()
    let fpayment = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            requestPaymentMessage: {
                currencyCodeIso4217: "USD",
                amount1000: SizeDoc(),
                requestFrom: Parti,
                noteMessage: {
                    extendedTextMessage: {
                        text: Sarapan
                    }
                },
                expiryTimestamp: SizeDoc(),
                amount: {
                    value: SizeDoc(),
                    offset: SizeDoc(),
                    currencyCode: "USD"
                }
            }
        }
    }
    let fpoll = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            pollCreationMessage: {
                name: Sarapan
            }
        }
    }
    let ftroli = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            orderMessage: {
                itemCount: SizeDoc(),
                status: 1,
                surface: 1,
                message: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                orderTitle: Sarapan,
                sellerJid: Parti
            }
        }
    }
    let fkontak = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            contactMessage: {
                displayName: Sarapan,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nN:XL;${Sarapan},;;;\nFN:${Sarapan},\nitem1.TEL;waid=${nomorown.split("@")[0]}:${nomorown.split("@")[0]}\nitem1.X-ABLabell:Ponsel\nEND:VCARD`,
                jpegThumbnail: Thum,
                thumbnail: Thum,
                sendEphemeral: true
            }
        }
    }
    let fvn = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            audioMessage: {
                mimetype: "audio/ogg; codecs=opus",
                seconds: SizeDoc(),
                ptt: true
            }
        }
    }
    let fvid = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            videoMessage: {
                title: Sarapan,
                h: Sarapan,
                seconds: SizeDoc(),
                caption: Sarapan,
                jpegThumbnail: Thum
            }
        }
    }
    let ftextt = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            extendedTextMessage: {
                text: Sarapan,
                title: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                jpegThumbnail: Thum
            }
        }
    }
    let fliveLoc = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            liveLocationMessage: {
                caption: Sarapan,
                h: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                jpegThumbnail: Thum
            }
        }
    }
    let ftoko = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            productMessage: {
                product: {
                    productImage: {
                        mimetype: "image/jpeg",
                        jpegThumbnail: Thum
                    },
                    title: Sarapan,
                    description: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                    currencyCode: "USD",
                    priceAmount1000: SizeDoc(),
                    retailerId: "Ghost",
                    productImageCount: 1
                },
                businessOwnerJid: Parti
            }
        }
    }
    let fdocs = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            documentMessage: {
                title: Sarapan,
                jpegThumbnail: Thum
            }
        }
    }
    let fgif = {
        key: {
            participant: Parti,
            remoteJid: Remot
        },
        message: {
            videoMessage: {
                title: Sarapan,
                h: Sarapan,
                seconds: SizeDoc(),
                gifPlayback: true,
                caption: `𝗧 𝗜 𝗠 𝗘 : ${moment.tz("Asia/Makassar").format("HH:mm:ss")}`,
                jpegThumbnail: Thum
            }
        }
    }
    return pickRandom([fdocs, fgif, fkontak, fliveLoc, fpayment, fpoll, ftextt, ftoko, ftroli, fvid, fvn])
}



function pickRandom(list) {
return list[Math.floor(list.length * Math.random())]
}
function SizeDoc() {
    return Math.pow(10, 15)
}
function PageDoc() {
    return Math.pow(10, 10)
}
function Sapa() {
    let Apa = pickRandom(["Apa kabar ", "Halo ", "Hai "])
    return Apa
}
function Pagi() {
    let waktunya = moment.tz("Asia/Jakarta").format("HH")
    let ucapin = "Selamat malam 🌙"
    if (waktunya >= 1) {
        ucapin = "Selamat Pagi "
    }
    if (waktunya >= 4) {
        ucapin = "Selamat pagi "
    }
    if (waktunya > 10) {
        ucapin = "Selamat siang "
    }
    if (waktunya >= 15) {
        ucapin = "Selamat sore "
    }
    if (waktunya >= 18) {
        ucapin = "Selamat malam "
    }
    if (waktunya >= 24) {
        ucapin = "Selamat Begadang "
    }
    return ucapin
}
function ucapan() {
const time = moment.tz('Asia/Jakarta').format('HH')
let res = "Selamat malam "
if (time >= 4) {
res = "Selamat pagi "
}
if (time > 10) {
res = "Selamat siang "
}
if (time >= 15) {
res = "Selamat sore "
}
if (time >= 18) {
res = "Selamat malam "
}
return res
}